document.getElementById('trackButton').addEventListener('click', () => {
  const walletAddress = document.getElementById('walletAddress').value;
  const rugList = document.getElementById('rugList');

  // Placeholder functionality for demonstration
  if (walletAddress) {
    const listItem = document.createElement('li');
    listItem.textContent = `Checked wallet: ${walletAddress}`;
    rugList.appendChild(listItem);
  } else {
    alert('Please enter a wallet address.');
  }
});
